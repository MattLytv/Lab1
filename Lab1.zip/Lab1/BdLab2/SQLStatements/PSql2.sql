﻿SELECT DISTINCT ep.ProjectsId
FROM EmployeeProject ep
WHERE ep.ProjectsId <> @Id
  AND NOT EXISTS (
    SELECT e.Id
    FROM Employees e
    WHERE e.id IN (SELECT e.EmployeesId FROM EmployeeProject e WHERE e.ProjectsId = @Id)
    AND e.id NOT IN (SELECT ep.EmployeesId FROM EmployeeProject ep WHERE ep.ProjectsId = ep.ProjectsId)
  )
  AND EXISTS (
    SELECT e.id
    FROM Employees e
    WHERE e.Id IN (SELECT ep.EmployeesId FROM EmployeeProject ep WHERE ep.ProjectsId = ep.ProjectsId)
    AND e.Id NOT IN (SELECT e.EmployeesId FROM EmployeeProject e WHERE e.ProjectsId = @Id)
  );
