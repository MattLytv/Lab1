﻿SELECT  p.Name AS ProjectName, p.Description, COUNT(DISTINCT e.Id) AS EmployeeCount
FROM Projects p
JOIN EmployeeProject ep ON p.Id = ep.ProjectsId
JOIN Employees e ON ep.EmployeesId = e.Id
JOIN Departments d ON e.DepartmentId = d.Id
WHERE d.Id = @Id
GROUP BY p.Id, p.Name, p.Description
