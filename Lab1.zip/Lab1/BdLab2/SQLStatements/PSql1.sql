﻿SELECT p.Id
FROM Projects p
WHERE p.id <> @Id
  AND NOT EXISTS (
    SELECT ep2.EmployeesId
    FROM EmployeeProject ep2
    WHERE ep2.ProjectsId = @Id
      AND ep2.EmployeesId NOT IN (
        SELECT ep.EmployeesId
        FROM EmployeeProject ep
        WHERE ep.ProjectsId = p.id
      )
  )
ORDER BY p.id;
