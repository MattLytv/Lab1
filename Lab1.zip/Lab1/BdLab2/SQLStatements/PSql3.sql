﻿SELECT DISTINCT ep1.ProjectsId
FROM EmployeeProject ep1
WHERE ep1.ProjectsId <> @Id
  AND NOT EXISTS (
    SELECT e.Id
    FROM Employees e
    WHERE e.Id IN (SELECT ep.EmployeesId FROM EmployeeProject ep  WHERE ep.ProjectsId = ep1.ProjectsId)
      AND NOT EXISTS (
        SELECT p2.Id
        FROM Employees p2
        WHERE p2.Id IN (SELECT p.EmployeesId FROM EmployeeProject p  WHERE p.ProjectsId = @Id)
          AND p2.Id = e.Id
      )
  )
  AND NOT EXISTS (
    SELECT e.Id
    FROM Employees e
    WHERE e.Id IN (SELECT p.EmployeesId FROM EmployeeProject p  WHERE p.ProjectsId = @Id)
      AND NOT EXISTS (
        SELECT e2.Id
        FROM Employees e2
        WHERE e2.Id IN (SELECT ep.EmployeesId FROM EmployeeProject ep  WHERE ep.ProjectsId = ep1.ProjectsId)
          AND e2.Id = e.Id
      )
  );
