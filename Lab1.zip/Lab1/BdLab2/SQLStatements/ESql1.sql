﻿--отримати всіх співробітників певного відділу з пов'язаними з ними проектами та завданнями
SELECT  e.Name AS EmployeeName,  pr.Name AS ProjectName,  t.Name AS TaskName
FROM Employees e
JOIN Departments d ON e.DepartmentId = d.Id
JOIN EmployeeProject ep ON e.Id = ep.EmployeesId
JOIN Projects pr ON ep.ProjectsId = pr.Id
JOIN Tasks t ON pr.Id = t.ProjectId
WHERE d.Id = @Id                            
