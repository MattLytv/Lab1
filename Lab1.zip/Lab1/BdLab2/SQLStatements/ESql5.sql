﻿SELECT t.Name AS TaskName, t.Description,  p.Name AS ProjectName
FROM Tasks t
JOIN Projects p ON t.ProjectId = p.Id
WHERE p.Id = @Id
