﻿SELECT  t.Name AS TaskName,  pr.Name AS ProjectName,  d.Name AS DepartmentName
FROM Tasks t
JOIN Projects pr ON t.ProjectId = pr.Id
JOIN EmployeeProject ep ON pr.Id = ep.ProjectsId
JOIN Employees e ON ep.EmployeesId = e.Id
JOIN Departments d ON e.DepartmentId = d.Id
WHERE e.Id = @Id
