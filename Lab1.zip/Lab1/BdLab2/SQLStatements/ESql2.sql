﻿SELECT  e.Name AS EmployeeName, e.JobTitle,  d.Name AS DepartmentName
FROM Employees e
JOIN Departments d ON e.DepartmentId = d.Id
JOIN EmployeeProject ep ON e.Id = ep.EmployeesId
JOIN Projects p ON ep.ProjectsId = p.Id
WHERE p.Id = @Id
