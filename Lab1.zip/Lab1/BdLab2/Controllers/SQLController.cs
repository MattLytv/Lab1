﻿using BdLab2.Context;
using BdLab2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace BdLab2.Controllers;
public class SQLController : Controller
{
    const string path = @"C:\Users\matve\Desktop\доки (1)\тарануха\BdLab2\BdLab2\SQLStatements"; 
    const string conn = @"Data Source=MATVII\SQLEXPRESS08;Initial Catalog=BdLaba2;Integrated Security=True;Encrypt=False;";   
    private readonly DbContextApp _context;

    public SQLController(DbContextApp context)
    {
        _context = context;
    }
    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult ESql1(Statements model)
    {
        var id = _context.Departments.FirstOrDefault(x => x.Id == model.Id);
        if (id == null)
        {
            if (model.Id < 0)
            {
                TempData["Error1"] = "Невірне значення!";
                return RedirectToAction("Index", "Sql");
            }
            TempData["Error2"] = $"Нема відділу з номером - {model.Id}!";
            return RedirectToAction("Index", "Sql");
        }
        model.StatementId = 1;
        string sqlFilePath = Path.Combine(path, "ESql1.sql");
        string sqlQuery = System.IO.File.ReadAllText(sqlFilePath);
        sqlQuery = sqlQuery.Replace("@Id", model.Id.ToString());
        model.Names = new List<string>();
        model.Projects = new List<string>();
        model.Tasks = new List<string>();

        using (var connection = new SqlConnection(conn))
        {
            connection.Open();
            using (var command = new SqlCommand(sqlQuery, connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        model.Names.Add(reader.GetString(0));
                        model.Projects.Add(reader.GetString(1));
                        model.Tasks.Add(reader.GetString(2));
                    }
                }
            }
        }
        return View("Result", model);
    }

    [HttpPost]
    public IActionResult ESql2(Statements model)
    {
        var id = _context.Projects.FirstOrDefault(x => x.Id == model.Id);
        if (id == null)
        {
            if (model.Id < 0)
            {
                TempData["Error3"] = "Невірне значення!";
                return RedirectToAction("Index", "Sql");
            }
            TempData["Error4"] = $"Нема проекту з ноемром - {model.Id}!";
            return RedirectToAction("Index", "Sql");
        }
        model.StatementId = 2;
        string sqlFilePath = Path.Combine(path, "ESql2.sql");
        string sqlQuery = System.IO.File.ReadAllText(sqlFilePath);
        sqlQuery = sqlQuery.Replace("@Id", model.Id.ToString());
        model.Names = new List<string>();
        model.Projects = new List<string>();
        model.Tasks = new List<string>();

        using (var connection = new SqlConnection(conn))
        {
            connection.Open();
            using (var command = new SqlCommand(sqlQuery, connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        model.Names.Add(reader.GetString(0));
                        model.Projects.Add(reader.GetString(1));
                        model.Tasks.Add(reader.GetString(2));
                    }
                }
            }
        }
        return View("Result", model);
    }

    [HttpPost]
    public IActionResult ESql3(Statements model)
    {
        var id = _context.Departments.FirstOrDefault(x => x.Id == model.Id);
        if (id == null)
        {
            if (model.Id < 0)
            {
                TempData["Error5"] = "Невірне значення!";
                return RedirectToAction("Index", "Sql");
            }
            TempData["Error6"] = $"Нема віддіілу з номером - {model.Id}!";
            return RedirectToAction("Index", "Sql");
        }
        model.StatementId = 3;
        string sqlFilePath = Path.Combine(path, "ESql3.sql");
        string sqlQuery = System.IO.File.ReadAllText(sqlFilePath);
        sqlQuery = sqlQuery.Replace("@Id", model.Id.ToString());
        model.Names = new List<string>();
        model.Projects = new List<string>();
        model.Count = new List<int>();
        using (var connection = new SqlConnection(conn))
        {
            connection.Open();
            using (var command = new SqlCommand(sqlQuery, connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        model.Names.Add(reader.GetString(0));
                        model.Projects.Add(reader.GetString(1));
                        model.Count.Add(reader.GetInt32(2));
                    }
                }
            }
        }
        return View("Result", model);
    }

    [HttpPost]
    public IActionResult ESql4(Statements model)
    {
        var id = _context.Employees.FirstOrDefault(x => x.Id == model.Id);
        if (id == null)
        {
            if (model.Id < 0)
            {
                TempData["Error7"] = "Невірне значення!";
                return RedirectToAction("Index", "Sql");
            }
            TempData["Error8"] = $"Нема співробітника з номером - {model.Id}!";
            return RedirectToAction("Index", "Sql");
        }
        model.StatementId = 4;
        string sqlFilePath = Path.Combine(path, "ESql4.sql");
        string sqlQuery = System.IO.File.ReadAllText(sqlFilePath);
        sqlQuery = sqlQuery.Replace("@Id", model.Id.ToString());
        model.Names = new List<string>();
        model.Projects = new List<string>();
        model.Tasks = new List<string>();
        using (var connection = new SqlConnection(conn))
        {
            connection.Open();
            using (var command = new SqlCommand(sqlQuery, connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        model.Names.Add(reader.GetString(0));
                        model.Projects.Add(reader.GetString(1));
                        model.Tasks.Add(reader.GetString(2));
                    }
                }
            }
        }
        return View("Result", model);
    }

    [HttpPost]
    public IActionResult ESql5(Statements model)
    {
        var id = _context.Projects.FirstOrDefault(x => x.Id == model.Id);
        if (id == null)
        {
            if (model.Id < 0)
            {
                TempData["Error9"] = "Невірне значення!";
                return RedirectToAction("Index", "Sql");
            }
            TempData["Error10"] = $"Нема проекту з номером - {model.Id}!";
            return RedirectToAction("Index", "Sql");
        }
        model.StatementId = 5;
        string sqlFilePath = Path.Combine(path, "ESql5.sql");
        string sqlQuery = System.IO.File.ReadAllText(sqlFilePath);
        sqlQuery = sqlQuery.Replace("@Id", model.Id.ToString());
        model.Names = new List<string>();
        model.Projects = new List<string>();
        model.Tasks = new List<string>();
        using (var connection = new SqlConnection(conn))
        {
            connection.Open();
            using (var command = new SqlCommand(sqlQuery, connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        model.Names.Add(reader.GetString(0));
                        model.Projects.Add(reader.GetString(1));
                        model.Tasks.Add(reader.GetString(2));
                    }
                }
            }
        }
        return View("Result", model);
    }

    [HttpPost]
    public IActionResult PSql1(Statements model)
    {
        var id = _context.Projects.FirstOrDefault(x => x.Id == model.Id);
        if (id == null)
        {
            if (model.Id < 0)
            {
                TempData["Error11"] = "Невірне значення!";
                return RedirectToAction("Index", "Sql");
            }
            TempData["Error12"] = $"Нема проекту з номером - {model.Id}!";
            return RedirectToAction("Index", "Sql");
        }
        model.StatementId = 6;
        string sqlFilePath = Path.Combine(path, "PSql1.sql");
        string sqlQuery = System.IO.File.ReadAllText(sqlFilePath);
        sqlQuery = sqlQuery.Replace("@Id", model.Id.ToString());
        model.Count = new List<int>();
        using (var connection = new SqlConnection(conn))
        {
            connection.Open();
            using (var command = new SqlCommand(sqlQuery, connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        model.Count.Add(reader.GetInt32(0));
                    }
                }
            }
        }
        return View("Result", model);
    }

    [HttpPost]
    public IActionResult PSql2(Statements model)
    {
        var id = _context.Projects.FirstOrDefault(x => x.Id == model.Id);
        if (id == null)
        {
            if (model.Id < 0)
            {
                TempData["Error13"] = "Невірне значення!";
                return RedirectToAction("Index", "Sql");
            }
            TempData["Error14"] = $"Нема проекту з номером - {model.Id}!";
            return RedirectToAction("Index", "Sql");
        }
        model.StatementId = 7;
        string sqlFilePath = Path.Combine(path, "PSql2.sql");
        string sqlQuery = System.IO.File.ReadAllText(sqlFilePath);
        sqlQuery = sqlQuery.Replace("@Id", model.Id.ToString());
        model.Count = new List<int>();
        using (var connection = new SqlConnection(conn))
        {
            connection.Open();
            using (var command = new SqlCommand(sqlQuery, connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        model.Count.Add(reader.GetInt32(0));
                    }
                }
            }
        }
        return View("Result", model);
    }

    [HttpPost]
    public IActionResult PSql3(Statements model)
    {
        var id = _context.Projects.FirstOrDefault(x => x.Id == model.Id);
        if (id == null)
        {
            if (model.Id < 0)
            {
                TempData["Error15"] = "Невірне значення!";
                return RedirectToAction("Index", "Sql");
            }
            TempData["Error16"] = $"Нема проекту з номером - {model.Id}!";
            return RedirectToAction("Index", "Sql");
        }
        model.StatementId = 8;
        string sqlFilePath = Path.Combine(path, "PSql3.sql");
        string sqlQuery = System.IO.File.ReadAllText(sqlFilePath);
        sqlQuery = sqlQuery.Replace("@Id", model.Id.ToString());
        model.Count = new List<int>();
        using (var connection = new SqlConnection(conn))
        {
            connection.Open();
            using (var command = new SqlCommand(sqlQuery, connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        model.Count.Add(reader.GetInt32(0));
                    }
                }
            }
        }
        return View("Result", model);
    }
}
