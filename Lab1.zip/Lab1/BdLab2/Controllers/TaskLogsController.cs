﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BdLab2.Context;
using BdLab2.Models;

namespace BdLab2.Controllers
{
    public class TaskLogsController : Controller
    {
        private readonly DbContextApp _context;

        public TaskLogsController(DbContextApp context)
        {
            _context = context;
        }

        // GET: TaskLogs
        public async Task<IActionResult> Index()
        {
            var dbContextApp = _context.TaskLogs.Include(t => t.Task);
            return View(await dbContextApp.ToListAsync());
        }

        // GET: TaskLogs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.TaskLogs == null)
            {
                return NotFound();
            }

            var taskLogs = await _context.TaskLogs
                .Include(t => t.Task)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (taskLogs == null)
            {
                return NotFound();
            }

            return View(taskLogs);
        }

        // GET: TaskLogs/Create
        public IActionResult Create()
        {
            ViewData["TaskId"] = new SelectList(_context.Tasks, "Id", "Id");
            return View();
        }

        // POST: TaskLogs/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Date,Description,TaskId")] TaskLogs taskLogs)
        {
            if (ModelState.IsValid)
            {
                _context.Add(taskLogs);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["TaskId"] = new SelectList(_context.Tasks, "Id", "Id", taskLogs.TaskId);
            return View(taskLogs);
        }

        // GET: TaskLogs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.TaskLogs == null)
            {
                return NotFound();
            }

            var taskLogs = await _context.TaskLogs.FindAsync(id);
            if (taskLogs == null)
            {
                return NotFound();
            }
            ViewData["TaskId"] = new SelectList(_context.Tasks, "Id", "Id", taskLogs.TaskId);
            return View(taskLogs);
        }

        // POST: TaskLogs/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Date,Description,TaskId")] TaskLogs taskLogs)
        {
            if (id != taskLogs.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(taskLogs);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TaskLogsExists(taskLogs.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["TaskId"] = new SelectList(_context.Tasks, "Id", "Id", taskLogs.TaskId);
            return View(taskLogs);
        }

        // GET: TaskLogs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.TaskLogs == null)
            {
                return NotFound();
            }

            var taskLogs = await _context.TaskLogs
                .Include(t => t.Task)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (taskLogs == null)
            {
                return NotFound();
            }

            return View(taskLogs);
        }

        // POST: TaskLogs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.TaskLogs == null)
            {
                return Problem("Entity set 'DbContextApp.TaskLogs'  is null.");
            }
            var taskLogs = await _context.TaskLogs.FindAsync(id);
            if (taskLogs != null)
            {
                _context.TaskLogs.Remove(taskLogs);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TaskLogsExists(int id)
        {
          return (_context.TaskLogs?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
