﻿using BdLab2.Models;
using Microsoft.EntityFrameworkCore;

namespace BdLab2.Context;

public class DbContextApp : DbContext
{
    public DbContextApp(DbContextOptions options) : base(options)
    {
    }

    public DbSet<Department> Departments { get; set; }
    public DbSet<Employee> Employees { get; set; }
    public DbSet<Project> Projects { get; set; }
    public DbSet<Tasks> Tasks { get; set; }
    public DbSet<BdLab2.Models.TaskLogs> TaskLogs { get; set; } = default!;
}
