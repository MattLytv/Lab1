﻿namespace BdLab2.Models;

public class Statements
{
    public int Id { get; set; }
    public int StatementId { get; set; }
    public List<string> Names { get; set; }
    public List<string> Projects { get; set; }
    public List<string> Tasks { get; set; }
    public List<int> Count { get; set; }
}
