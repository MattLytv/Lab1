﻿namespace BdLab2.Models;

public class TaskLogs
{
    public int Id { get; set; }
    public DateTime Date { get; set; }
    public string Description { get; set; }
    public int? TaskId { get; set; }
    public Tasks? Task { get; set; }
}
